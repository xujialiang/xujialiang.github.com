//
//  XJLViewController.m
//  amrrecord
//
//  Created by Elliott on 14-4-23.
//  Copyright (c) 2014年 Elliott. All rights reserved.
//

#import "XJLViewController.h"
#import "MBProgressHUD.h"
#import "XJLButtonPress.h"
@interface XJLViewController ()<UIGestureRecognizerDelegate>{
    MBProgressHUD *HUD;
    BOOL iscalcel;
    bool ispress;
}
- (IBAction)btndown:(id)sender;
- (IBAction)btnup:(id)sender;
- (IBAction)btnexit:(id)sender;
- (IBAction)btndragin:(id)sender;
@property (weak, nonatomic) IBOutlet XJLButtonPress *btnbutton;

@end

@implementation XJLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.navigationController.interactivePopGestureRecognizer.enabled=YES;
    self.navigationController.interactivePopGestureRecognizer.delegate=self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btndown:(id)sender {
    iscalcel=NO;
    
    if (!ispress) {
        HUD = [[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        
        HUD.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark.png"]];
        
        HUD.mode = MBProgressHUDModeCustomView;
        
        HUD.labelText = @"down";
        UITapGestureRecognizer *oneFingerTwoTaps =[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(oneFingerTwoTaps)];
        [HUD addGestureRecognizer:oneFingerTwoTaps];
        
        [HUD show:YES];
        ispress=YES;
    }
}



// called before touchesBegan:withEvent: is called on the gesture recognizer for a new touch. return NO to prevent the gesture recognizer from seeing this touch
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    if ([touch.view isKindOfClass:[XJLButtonPress class]]) {
        [self.btnbutton sendActionsForControlEvents:UIControlEventTouchDown];
        return NO;
    }
    return YES;
}



- (void)oneFingerTwoTaps
{
    ispress=NO;
    [HUD removeFromSuperview];
}

- (IBAction)btnup:(id)sender {
    if (ispress) {
        HUD.labelText=@"up";
        [HUD removeFromSuperview];
        ispress=NO;
    }
    
}

- (IBAction)btnexit:(id)sender {
    HUD.labelText=@"drag exit";
    iscalcel=YES;
}

- (IBAction)btndragin:(id)sender {
    HUD.labelText=@"drag in";
    iscalcel=NO;
}
@end
