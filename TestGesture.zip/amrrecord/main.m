//
//  main.m
//  amrrecord
//
//  Created by Elliott on 14-4-23.
//  Copyright (c) 2014年 Elliott. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XJLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XJLAppDelegate class]));
    }
}
