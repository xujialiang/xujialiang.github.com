//
//  XJLAppDelegate.h
//  amrrecord
//
//  Created by Elliott on 14-4-23.
//  Copyright (c) 2014年 Elliott. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XJLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
