//
//  XJLButtonPress.h
//  amrrecord
//
//  Created by Elliott on 14-4-25.
//  Copyright (c) 2014年 Elliott. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XJLButtonPress : UIButton

@end
